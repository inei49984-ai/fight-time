import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const $ = (id) => document.getElementById(id);

// ---------- キャラ情報 ----------
// yaw: モデルの正面を +X 方向へ向けるための回転。fit: 大きさの揃え方。
// ※ 向きが逆に見えたら yaw の符号(±Math.PI/2)を入れ替えてください。
const CHARS = {
  soldier: { name: 'ソルジャー', desc: 'バランス型', url: '/assets/soldier.glb', yaw: Math.PI / 2, fit: { h: 1.9 }, stats: [3, 3, 3] },
  super:   { name: 'スーパーヒューマン', desc: 'パワー型', url: '/assets/super.glb', yaw: -Math.PI / 2, fit: { h: 2.2 }, stats: [5, 1, 4] },
  thomas:  { name: 'トーマス', desc: 'スピード型', url: '/assets/thomas.glb', yaw: -Math.PI / 2, fit: { len: 2.6 }, stats: [2, 5, 2] },
};
const STAT_LABELS = ['パワー', 'スピード', 'たいりょく'];

// ---------- three.js 基本 ----------
const canvas = $('gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
const pmrem = new THREE.PMREMGenerator(renderer);
const envMap = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

function makeScene(bg) {
  const s = new THREE.Scene();
  s.background = new THREE.Color(bg); s.fog = new THREE.Fog(bg, 18, 48);
  s.environment = envMap; s.environmentIntensity = 0.7;
  s.add(new THREE.HemisphereLight(0xbfd4ff, 0x30283a, 0.7));
  const d = new THREE.DirectionalLight(0xffffff, 2.2); d.position.set(4, 9, 6); s.add(d);
  return s;
}
const previewScene = makeScene(0x10131f);
const fightScene = makeScene(0x141a30);
const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100);

function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

// 床テクスチャ(グリッド)
function gridTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
  g.fillStyle = '#1d2440'; g.fillRect(0, 0, 256, 256); g.strokeStyle = '#2f3b6b'; g.lineWidth = 3; g.strokeRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(40, 40); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
function addFloor(scene, withEdges) {
  const floor = new THREE.Mesh(new THREE.CircleGeometry(40, 64), new THREE.MeshStandardMaterial({ map: gridTexture(), roughness: 0.9, metalness: 0 }));
  floor.rotation.x = -Math.PI / 2; scene.add(floor);
  if (withEdges) {
    const m = new THREE.MeshStandardMaterial({ color: 0xffb020, emissive: 0xff8a00, emissiveIntensity: 0.9 });
    for (const x of [-6.9, 6.9]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.25, 4, 0.25), m); p.position.set(x, 2, -0.6); scene.add(p); }
    const line = new THREE.Mesh(new THREE.BoxGeometry(14, 0.02, 0.08), new THREE.MeshBasicMaterial({ color: 0xffb020 })); line.position.set(0, 0.012, 0.9); scene.add(line);
  }
}
addFloor(previewScene, false); addFloor(fightScene, true);
const ped = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.12, 48), new THREE.MeshStandardMaterial({ color: 0x252c4d, roughness: 0.5, metalness: 0.4 }));
ped.position.y = -0.06; previewScene.add(ped);

// ---------- モデル読み込み ----------
const loader = new GLTFLoader();
const cache = new Map();
let progressCb = null;
function loadChar(key) {
  if (cache.has(key)) return cache.get(key);
  const c = CHARS[key];
  const p = new Promise((res, rej) => {
    loader.load(c.url, (gltf) => {
      const holder = new THREE.Group(); holder.add(gltf.scene);
      holder.rotation.y = c.yaw;
      const wrap = new THREE.Group(); wrap.add(holder);
      wrap.updateMatrixWorld(true);
      // 大きさ・位置の正規化 (足元が y=0、中心が原点)
      let box = new THREE.Box3().setFromObject(wrap), size = box.getSize(new THREE.Vector3());
      const s = c.fit.h ? c.fit.h / size.y : c.fit.len / Math.max(size.x, size.z);
      wrap.scale.setScalar(s); wrap.updateMatrixWorld(true);
      box = new THREE.Box3().setFromObject(wrap); const ctr = box.getCenter(new THREE.Vector3());
      wrap.position.set(-ctr.x, -box.min.y, -ctr.z);
      const root = new THREE.Group(); root.add(wrap);
      c.height = box.max.y - box.min.y;
      res(root);
    }, (e) => { if (progressCb && e.total) progressCb(key, e.loaded / e.total); }, rej);
  });
  cache.set(key, p); return p;
}
function instance(root) {
  const g = root.clone(true);
  g.traverse((o) => { if (o.isMesh) { o.material = Array.isArray(o.material) ? o.material.map((m) => m.clone()) : o.material.clone(); } });
  return g;
}
function flash(g, amount) {
  g.traverse((o) => { if (o.isMesh) { for (const m of [].concat(o.material)) { if (m.emissive) { m.emissive.setRGB(amount, amount * 0.1, amount * 0.1); } } } });
}

// ---------- 画面遷移 ----------
const screens = ['s-title', 's-select', 's-wait'];
let mode = 'title';
function show(name) {
  mode = name;
  for (const s of screens) $(s).classList.toggle('hidden', s !== 's-' + name);
  $('hud').classList.toggle('hidden', name !== 'fight');
}
function toast(t) { const e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('on'), 2500); }

const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* 無視 */ } };
const load = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
$('name').value = load('name') || '';
let myChar = load('char') in CHARS ? load('char') : 'soldier';
let joinRoom = '';

// ---------- キャラ選択 ----------
let preview = null, previewKey = null;
function buildCards() {
  $('cards').innerHTML = '';
  for (const [k, c] of Object.entries(CHARS)) {
    const el = document.createElement('div'); el.className = 'card' + (k === myChar ? ' on' : '');
    el.innerHTML = `<b>${c.name}</b><small>${c.desc}</small>`;
    el.onclick = () => pick(k); $('cards').appendChild(el);
  }
}
async function pick(k) {
  myChar = k; save('char', k); buildCards();
  const st = CHARS[k].stats;
  $('stats').innerHTML = STAT_LABELS.map((l, i) => `<span>${l}</span><div class="meter"><i style="width:${st[i] * 20}%"></i></div>`).join('');
  previewKey = k;
  const root = await loadChar(k);
  if (previewKey !== k) return;
  if (preview) previewScene.remove(preview);
  preview = instance(root); previewScene.add(preview);
}
$('btn-quick').onclick = () => { joinRoom = ''; toSelect(); };
$('btn-room').onclick = () => { joinRoom = $('room').value.trim().toUpperCase(); if (!joinRoom) return toast('ルームコードを入力してください'); toSelect(); };
function toSelect() { save('name', $('name').value); show('select'); pick(myChar); }
$('btn-back').onclick = () => show('title');
$('btn-go').onclick = () => connect();

// ---------- ネットワーク ----------
let ws = null, hb = null, you = 0, roster = null, snap = null, tries = 0, wantConnect = false;
function setWait(title, sub, room) { $('wait-title').textContent = title; $('wait-sub').textContent = sub || ''; $('wait-room').textContent = room || ''; }
function connect() {
  wantConnect = true; tries = 0; show('wait'); setWait('サーバーに接続中…', '無料プランのため、起動に最大1分ほどかかることがあります');
  open();
}
function open() {
  if (!wantConnect) return;
  ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
  ws.onopen = () => {
    tries = 0;
    ws.send(JSON.stringify({ t: 'join', name: $('name').value || 'PLAYER', char: myChar, room: joinRoom || undefined }));
    clearInterval(hb); hb = setInterval(() => ws.readyState === 1 && ws.send('{"t":"ping"}'), 20000);
  };
  ws.onmessage = (e) => onMsg(JSON.parse(e.data));
  ws.onclose = () => {
    clearInterval(hb);
    if (!wantConnect) return;
    if (mode === 'fight') { toast('接続が切れました'); return exitToTitle(); }
    if (++tries < 40) setTimeout(open, 2500); else { toast('接続できませんでした'); exitToTitle(); }
  };
  ws.onerror = () => { /* onclose で再試行 */ };
}
function disconnect() { wantConnect = false; clearInterval(hb); if (ws) { ws.onclose = null; try { ws.close(); } catch (e) { /* 無視 */ } ws = null; } }
function exitToTitle() { disconnect(); fighters.forEach((f) => fightScene.remove(f.root)); fighters = []; roster = null; snap = null; show('title'); }
$('btn-cancel').onclick = exitToTitle; $('btn-exit').onclick = exitToTitle;
$('btn-rematch').onclick = () => { ws && ws.send('{"t":"rematch"}'); $('btn-rematch').textContent = '相手を待っています…'; };

function onMsg(m) {
  if (m.t === 'joined') { you = m.you; }
  else if (m.t === 'wait') { setWait('相手を待っています…', joinRoom ? '友達にこのルームコードを伝えてください' : '他のプレイヤーが来るまでお待ちください', joinRoom ? m.room : ''); }
  else if (m.t === 'left') { toast('相手が退出しました'); fighters.forEach((f) => fightScene.remove(f.root)); fighters = []; snap = null; show('wait'); setWait('相手を待っています…', '', joinRoom ? m.room : ''); }
  else if (m.t === 'err') { toast(m.m); exitToTitle(); }
  else if (m.t === 'start') { startFight(m.players); }
  else if (m.t === 's') { onSnap(m); }
}

// ---------- 対戦 ----------
let fighters = [];
async function startFight(players) {
  roster = players; $('loading').classList.remove('hidden');
  const total = new Set(players.map((p) => p.char)).size; const prog = {};
  progressCb = (k, f) => { prog[k] = f; const v = Object.values(prog).reduce((a, b) => a + b, 0) / total; $('load-bar').style.width = (v * 100) + '%'; $('load-text').textContent = 'モデル読み込み中 ' + Math.round(v * 100) + '%'; };
  const roots = await Promise.all(players.map((p) => loadChar(p.char)));
  progressCb = null; $('loading').classList.add('hidden');
  fighters.forEach((f) => fightScene.remove(f.root)); fighters = [];
  players.forEach((p, i) => {
    const root = new THREE.Group(), lean = new THREE.Group(), model = instance(roots[i]);
    lean.add(model); root.add(lean); fightScene.add(root);
    const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.8, 24), new THREE.MeshBasicMaterial({ color: 0, transparent: true, opacity: 0.4 }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.01; fightScene.add(shadow);
    const f = { root, lean, model, shadow, x: i ? 3 : -3, y: 0, face: i ? -1 : 1, cur: { z: 0, x: 0, sy: 1, by: 0 }, red: 0, t: 0, h: CHARS[p.char].height || 1.9 };
    root.position.set(f.x, 0, 0); fighters.push(f);
  });
  $('n0').textContent = players[0].name; $('n1').textContent = players[1].name;
  $('over').classList.add('hidden'); $('btn-rematch').textContent = 'もう一度'; $('banner').textContent = '';
  show('fight');
}

const spark = [];
function burst(x, y, blocked) {
  for (let i = 0; i < 8; i++) {
    const m = new THREE.Mesh(new THREE.IcosahedronGeometry(0.06, 0), new THREE.MeshBasicMaterial({ color: blocked ? 0x7fc4ff : 0xffd84a, transparent: true }));
    m.position.set(x, y, 0.3); const a = Math.random() * Math.PI * 2, sp = 2 + Math.random() * 3;
    spark.push({ m, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp + 1, life: 0.35 }); fightScene.add(m);
  }
}
let shake = 0;

let audio = null;
function sfx(kind) {
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    const t = audio.currentTime, o = audio.createOscillator(), g = audio.createGain();
    o.type = kind === 'block' ? 'square' : 'sawtooth';
    o.frequency.setValueAtTime(kind === 'block' ? 520 : kind === 'heavy' ? 120 : 220, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.15);
    g.gain.setValueAtTime(0.18, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    o.connect(g).connect(audio.destination); o.start(t); o.stop(t + 0.2);
  } catch (e) { /* 音が出なくても続行 */ }
}

let lastPhase = '', fightBannerUntil = 0;
function onSnap(s) {
  snap = s;
  s.p.forEach((p, i) => {
    $('hp' + i).style.width = (p.hp / roster[i].maxHp * 100) + '%';
    $('pip' + i).innerHTML = [0, 1].map((k) => `<span class="${k < p.w ? 'w' : ''}"></span>`).join('');
    if (p.h && fighters[i]) { burst(p.x, 1.1 + p.y, p.h.blocked); sfx(p.h.blocked ? 'block' : p.h.kind); shake = p.h.kind === 'heavy' && !p.h.blocked ? 0.25 : 0.1; if (!p.h.blocked) fighters[i].red = 1; }
  });
  $('clock').textContent = s.tm; $('round').textContent = 'ROUND ' + s.rd;
  if (s.ph === 'fight' && lastPhase === 'countdown') fightBannerUntil = performance.now() + 900;
  let b = '';
  if (s.ph === 'countdown') b = s.pt > 0 ? String(s.pt) : '';
  else if (s.ph === 'fight') b = performance.now() < fightBannerUntil ? 'FIGHT!' : '';
  else b = s.msg;   // roundover / matchover
  $('banner').textContent = b;
  $('over').classList.toggle('hidden', s.ph !== 'matchover');
  lastPhase = s.ph;
}

// ---------- 入力 ----------
const keys = new Set();
const MAP = { KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r', KeyW: 'j', ArrowUp: 'j', Space: 'j', KeyJ: 'a', KeyK: 'h', KeyL: 'b', KeyS: 'b', ArrowDown: 'b' };
const BIT = { l: 1, r: 2, j: 4, a: 8, h: 16, b: 32 };
let sent = -1, sentAt = 0;
function pushInput() {
  let v = 0; for (const k of keys) v |= BIT[k];
  const now = performance.now();
  if (ws && ws.readyState === 1 && mode === 'fight' && (v !== sent || now - sentAt > 200)) { ws.send(JSON.stringify({ t: 'in', i: v })); sent = v; sentAt = now; }
}
addEventListener('keydown', (e) => { if (MAP[e.code] && mode === 'fight') { keys.add(MAP[e.code]); e.preventDefault(); pushInput(); } });
addEventListener('keyup', (e) => { if (MAP[e.code]) { keys.delete(MAP[e.code]); pushInput(); } });
addEventListener('blur', () => { keys.clear(); pushInput(); });
document.querySelectorAll('#touch button').forEach((b) => {
  const k = b.dataset.k;
  b.addEventListener('pointerdown', (e) => { e.preventDefault(); keys.add(k); pushInput(); });
  for (const ev of ['pointerup', 'pointerleave', 'pointercancel']) b.addEventListener(ev, () => { keys.delete(k); pushInput(); });
});

// ---------- 手続きアニメーション ----------
const MOVES = { light: { start: 4, active: 3, recover: 8 }, heavy: { start: 11, active: 4, recover: 16 } };
const ease = (t) => t * t * (3 - 2 * t);
function pose(f, p, t) {
  // 返り値: z=前傾(+で後ろ), x=前への突進, sy=縦の潰れ, by=浮き
  let z = 0, x = 0, sy = 1, by = 0;
  const br = Math.sin(t * 3) * 0.012;
  if (p.s === 'idle') { sy = 1 + br; }
  else if (p.s === 'walk') { by = Math.abs(Math.sin(t * 11)) * 0.07; z = -0.07 + Math.sin(t * 11) * 0.05; }
  else if (p.s === 'jump') { z = -0.12; sy = 1.04; }
  else if (p.s === 'block') { sy = 0.88; z = 0.14; x = -0.1; }
  else if (p.s === 'hurt') { z = 0.4; x = -0.3; }
  else if (p.s === 'ko') { z = 1.5; by = 0.0; x = -0.5; }
  else if (p.s === 'attack' && MOVES[p.m]) {
    const m = MOVES[p.m], heavy = p.m === 'heavy', st = p.st;
    const reach = heavy ? 1.0 : 0.55, lean = heavy ? 0.75 : 0.4, wind = heavy ? 0.45 : 0.18;
    if (st < m.start) { const k = ease(st / m.start); z = wind * k; x = -0.15 * k; }
    else if (st < m.start + m.active) { z = -lean; x = reach; }
    else { const k = ease((st - m.start - m.active) / m.recover); z = -lean * (1 - k); x = reach * (1 - k); }
  }
  return { z, x, sy, by };
}

// ---------- メインループ ----------
const clock = new THREE.Clock();
const camTarget = new THREE.Vector3(), camPos = new THREE.Vector3(0, 2.6, 11);
function frame() {
  const dt = Math.min(clock.getDelta(), 0.1), now = clock.elapsedTime;
  if (mode === 'fight' && fighters.length === 2 && snap) {
    const kx = 1 - Math.exp(-dt * 24);
    fighters.forEach((f, i) => {
      const p = snap.p[i]; f.t += dt;
      f.x += (p.x - f.x) * kx; f.y += (p.y - f.y) * kx; f.face = p.f;
      const target = pose(f, p, f.t), c = f.cur, k = 1 - Math.exp(-dt * 22);
      c.z += (target.z - c.z) * k; c.x += (target.x - c.x) * k; c.sy += (target.sy - c.sy) * k; c.by += (target.by - c.by) * k;
      f.root.position.set(f.x, f.y + c.by, 0);
      f.root.rotation.y += ((p.f > 0 ? 0 : Math.PI) - f.root.rotation.y) * (1 - Math.exp(-dt * 18));
      f.lean.rotation.z = -c.z; f.lean.position.x = c.x; f.lean.scale.y = c.sy;
      if (p.s === 'ko') f.lean.position.y = 0.2 * Math.min(1, c.z);
      else f.lean.position.y = 0;
      f.red = Math.max(0, f.red - dt * 3); flash(f.model, f.red * 0.8);
      f.shadow.position.x = f.x; f.shadow.scale.setScalar(Math.max(0.4, 1 - f.y * 0.25));
    });
    const [a, b] = fighters, mid = (a.x + b.x) / 2, gap = Math.abs(a.x - b.x);
    const dist = Math.max(9, gap * 1.05 + 6.5);
    camTarget.set(mid, 1.3, 0); camPos.lerp(new THREE.Vector3(mid, 2.4, dist), 1 - Math.exp(-dt * 4));
    camera.position.copy(camPos);
    if (shake > 0) { camera.position.x += (Math.random() - 0.5) * shake; camera.position.y += (Math.random() - 0.5) * shake; shake = Math.max(0, shake - dt * 1.2); }
    camera.lookAt(camTarget);
    for (let i = spark.length - 1; i >= 0; i--) {
      const s = spark[i]; s.life -= dt; s.vy -= 9 * dt; s.m.position.x += s.vx * dt; s.m.position.y += s.vy * dt; s.m.material.opacity = Math.max(0, s.life / 0.35);
      if (s.life <= 0) { fightScene.remove(s.m); spark.splice(i, 1); }
    }
    renderer.render(fightScene, camera);
  } else if (mode === 'select' || mode === 'title' || mode === 'wait') {
    if (preview) { preview.rotation.y = now * 0.6; const h = CHARS[previewKey].height || 2; camera.position.set(h * 1.0 + 1.6, h * 0.55 + 0.4, h * 1.6 + 2.4); camera.lookAt(h * 0.28, h * 0.5, 0); preview.visible = mode !== 'wait'; }
    else { camera.position.set(3, 1.6, 5); camera.lookAt(0, 1, 0); }
    renderer.render(previewScene, camera);
  } else renderer.render(fightScene, camera);
  requestAnimationFrame(frame);
}
buildCards(); show('title');
// タイトル背景にも選択中キャラを表示
loadChar(myChar).then((r) => { if (!preview) { previewKey = myChar; preview = instance(r); previewScene.add(preview); } }).catch(() => {});
requestAnimationFrame(frame);

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
