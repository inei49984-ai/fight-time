// モデル(GLB)と three.js をキャッシュして2回目以降を高速化。HTML/JSは常に最新を優先。
const CACHE = 'fighters-v1';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(
  caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
));
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname === '/ws') return;
  const heavy = u.pathname.endsWith('.glb') || u.hostname === 'cdn.jsdelivr.net';
  if (heavy) {
    e.respondWith(caches.open(CACHE).then(async (c) => {
      const hit = await c.match(e.request); if (hit) return hit;
      const res = await fetch(e.request); if (res.ok) c.put(e.request, res.clone()); return res;
    }));
  } else if (u.origin === location.origin) {
    e.respondWith(fetch(e.request).then((r) => { const cp = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request)));
  }
});
