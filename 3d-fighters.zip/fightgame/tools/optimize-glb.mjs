// GLB内のテクスチャを縮小してWebP化し、配信サイズを減らす (node tools/optimize-glb.mjs in.glb out.glb [maxTex])
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const sharp = require('sharp');

const [,, inp, outp, maxTexArg] = process.argv;
const MAX = Number(maxTexArg || 1024);
const buf = fs.readFileSync(inp);
const jsonLen = buf.readUInt32LE(12);
const json = JSON.parse(buf.slice(20, 20 + jsonLen).toString('utf8'));
const binStart = 20 + jsonLen + 8;
const bin = buf.slice(binStart, binStart + buf.readUInt32LE(20 + jsonLen));

const imageViews = new Map();
(json.images || []).forEach((img, i) => { if (img.bufferView !== undefined) imageViews.set(img.bufferView, i); });

const parts = [];
let offset = 0;
for (let i = 0; i < json.bufferViews.length; i++) {
  const bv = json.bufferViews[i];
  let data = bin.slice(bv.byteOffset || 0, (bv.byteOffset || 0) + bv.byteLength);
  if (imageViews.has(i)) {
    const meta = await sharp(data).metadata();
    const scale = Math.min(1, MAX / Math.max(meta.width, meta.height));
    let p = sharp(data);
    if (scale < 1) p = p.resize(Math.round(meta.width * scale), Math.round(meta.height * scale));
    data = await p.webp({ quality: 82 }).toBuffer();
    json.images[imageViews.get(i)].mimeType = 'image/webp';
  }
  const pad = (4 - (offset % 4)) % 4;
  if (pad) { parts.push(Buffer.alloc(pad)); offset += pad; }
  bv.byteOffset = offset; bv.byteLength = data.length;
  parts.push(data); offset += data.length;
}
const newBin = Buffer.concat(parts);
const binPad = Buffer.alloc((4 - (newBin.length % 4)) % 4);
json.buffers[0].byteLength = newBin.length;
delete json.buffers[0].uri;
let js = Buffer.from(JSON.stringify(json), 'utf8');
js = Buffer.concat([js, Buffer.alloc((4 - (js.length % 4)) % 4, 0x20)]);
const binChunk = Buffer.concat([newBin, binPad]);
const total = 12 + 8 + js.length + 8 + binChunk.length;
const head = Buffer.alloc(12); head.write('glTF', 0); head.writeUInt32LE(2, 4); head.writeUInt32LE(total, 8);
const jh = Buffer.alloc(8); jh.writeUInt32LE(js.length, 0); jh.write('JSON', 4);
const bh = Buffer.alloc(8); bh.writeUInt32LE(binChunk.length, 0); bh.write('BIN\0', 4);
fs.writeFileSync(outp, Buffer.concat([head, jh, js, bh, binChunk]));
console.log(inp.split('/').pop(), (buf.length/1e6).toFixed(1)+'MB ->', (total/1e6).toFixed(1)+'MB');
