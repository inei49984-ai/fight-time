// 対戦格闘ゲーム サーバー (依存パッケージなし / Node 18+)
// HTTP静的配信 + 自前WebSocket(RFC6455)。サーバーが判定を持つ権威サーバー方式。
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.glb': 'model/gltf-binary', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

// ---------- ゲーム定義 ----------
const TICK = 30;                 // サーバー更新Hz
const DT = 1 / TICK;
const ARENA = 6;                 // 移動範囲 -ARENA..ARENA
const GRAVITY = 26, JUMP_V = 10;
const ROUNDS_TO_WIN = 2, ROUND_TIME = 60;

const CHARS = {
  soldier: { name: 'ソルジャー', hp: 100, speed: 4.6, dmg: 1.0, reachL: 1.5, reachH: 1.9 },
  super:   { name: 'スーパーヒューマン', hp: 130, speed: 3.4, dmg: 1.3, reachL: 1.7, reachH: 2.1 },
  thomas:  { name: 'トーマス', hp: 90, speed: 6.2, dmg: 0.9, reachL: 1.8, reachH: 2.6 },
};
// 攻撃フレーム(tick): 発生 / 持続 / 硬直, ダメージ, ヒットストップ(のけぞり)
const MOVES = {
  light: { start: 4,  active: 3, recover: 8,  dmg: 6,  stun: 9,  knock: 2.5 },
  heavy: { start: 11, active: 4, recover: 16, dmg: 15, stun: 16, knock: 6.0 },
};

const rooms = new Map();   // code -> room
let waiting = null;        // クイックマッチ待ち room

function newPlayer(ws, name, char) {
  const c = CHARS[char] ? char : 'soldier';
  return { ws, name: String(name || 'PLAYER').slice(0, 12), char: c, side: 0, input: {}, wins: 0, rematch: false,
    x: 0, y: 0, vy: 0, hp: CHARS[c].hp, maxHp: CHARS[c].hp, face: 1,
    state: 'idle', stateT: 0, move: null, hit: false, stun: 0, block: false };
}

function makeRoom(code) {
  return { code, players: [], phase: 'waiting', phaseT: 0, round: 1, timer: ROUND_TIME, tick: 0, winner: null, msg: '' };
}

function resetRound(room) {
  room.players.forEach((p, i) => {
    p.x = i === 0 ? -3 : 3; p.y = 0; p.vy = 0; p.hp = p.maxHp; p.face = i === 0 ? 1 : -1;
    p.state = 'idle'; p.stateT = 0; p.move = null; p.hit = false; p.stun = 0; p.block = false;
  });
  room.timer = ROUND_TIME;
  room.phase = 'countdown'; room.phaseT = 3 * TICK;
}

function startMatch(room) {
  room.players.forEach((p, i) => { p.side = i; p.wins = 0; p.rematch = false; });
  room.round = 1; room.winner = null;
  resetRound(room);
  broadcast(room, { t: 'start', players: room.players.map(pub) });
}

const pub = (p) => ({ name: p.name, char: p.char, maxHp: p.maxHp, side: p.side });

function send(ws, obj) {
  if (ws.destroyed || !ws.writable) return;
  const data = Buffer.from(JSON.stringify(obj));
  let head;
  if (data.length < 126) head = Buffer.from([0x81, data.length]);
  else if (data.length < 65536) { head = Buffer.alloc(4); head[0] = 0x81; head[1] = 126; head.writeUInt16BE(data.length, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x81; head[1] = 127; head.writeBigUInt64BE(BigInt(data.length), 2); }
  ws.write(Buffer.concat([head, data]));
}
function broadcast(room, obj) { room.players.forEach((p) => send(p.ws, obj)); }

// ---------- シミュレーション ----------
function startAttack(p, kind) {
  p.state = 'attack'; p.move = kind; p.stateT = 0; p.hit = false;
}

function stepPlayer(p, foe, room) {
  const ch = CHARS[p.char];
  const inp = p.input;
  const fighting = room.phase === 'fight';
  const grounded = p.y <= 0;

  p.face = foe.x >= p.x ? 1 : -1;
  p.stateT++;

  if (p.state === 'hurt') {
    p.stun--; if (p.stun <= 0) { p.state = 'idle'; }
  } else if (p.state === 'attack') {
    const m = MOVES[p.move];
    if (p.stateT >= m.start + m.active + m.recover) { p.state = 'idle'; p.move = null; }
  } else if (p.state === 'ko') {
    /* 何もしない */
  }

  const free = fighting && (p.state === 'idle' || p.state === 'walk' || p.state === 'block' || p.state === 'jump');
  p.block = false;
  if (free) {
    let vx = 0;
    if (inp.l) vx -= 1; if (inp.r) vx += 1;
    if (grounded && inp.b) { p.block = true; p.state = 'block'; vx = 0; }
    else {
      if (grounded) p.state = vx ? 'walk' : 'idle';
      p.x += vx * ch.speed * (grounded ? 1 : 0.8) * DT;
      if (inp.j && grounded) { p.vy = JUMP_V; p.state = 'jump'; }
      if (inp.a && inp.a !== p._pa) startAttack(p, 'light');
      else if (inp.h && inp.h !== p._ph) startAttack(p, 'heavy');
    }
  }
  p._pa = inp.a; p._ph = inp.h;

  // 重力
  if (p.y > 0 || p.vy > 0) {
    p.vy -= GRAVITY * DT; p.y += p.vy * DT;
    if (p.y <= 0) { p.y = 0; p.vy = 0; if (p.state === 'jump') p.state = 'idle'; }
  }
  // 押し戻し・アリーナ制限
  p.x = Math.max(-ARENA, Math.min(ARENA, p.x));
}

function resolveHits(a, b) {
  if (a.state !== 'attack') return;
  const m = MOVES[a.move];
  if (a.hit || a.stateT < m.start || a.stateT >= m.start + m.active) return;
  const ch = CHARS[a.char];
  const reach = a.move === 'light' ? ch.reachL : ch.reachH;
  const dx = (b.x - a.x) * a.face;
  if (dx < 0 || dx > reach + 0.4 || Math.abs(b.y - a.y) > 1.3 || b.state === 'ko') return;
  a.hit = true;
  let dmg = m.dmg * ch.dmg;
  const blocked = b.block && b.face === -a.face;
  if (blocked) { dmg *= 0.15; b.x += a.face * 0.4; }
  else {
    b.state = 'hurt'; b.stun = m.stun; b.stateT = 0; b.move = null;
    b.x += a.face * m.knock * 0.12;
    if (a.move === 'heavy') b.vy = Math.max(b.vy, 4);
  }
  b.hp = Math.max(0, b.hp - dmg);
  b.lastHit = { blocked, kind: a.move };
  if (b.hp <= 0) { b.state = 'ko'; }
}

function endRound(room, winnerIdx) {
  room.phase = 'roundover'; room.phaseT = 3 * TICK;
  if (winnerIdx >= 0) {
    room.players[winnerIdx].wins++;
    room.msg = room.players[winnerIdx].name + ' の勝ち!';
  } else room.msg = '引き分け';
  const champ = room.players.findIndex((p) => p.wins >= ROUNDS_TO_WIN);
  if (champ >= 0) { room.phase = 'matchover'; room.winner = champ; room.msg = room.players[champ].name + ' が勝利!'; }
}

function tickRoom(room) {
  room.tick++;
  if (room.players.length < 2) return;
  const [a, b] = room.players;

  if (room.phase === 'countdown') {
    room.phaseT--;
    if (room.phaseT <= 0) { room.phase = 'fight'; }
  } else if (room.phase === 'fight') {
    stepPlayer(a, b, room); stepPlayer(b, a, room);
    // 体の押し合い
    const gap = Math.abs(a.x - b.x), minGap = 0.9;
    if (gap < minGap && Math.abs(a.y - b.y) < 1.0) {
      const push = (minGap - gap) / 2, dir = a.x <= b.x ? 1 : -1;
      a.x -= dir * push; b.x += dir * push;
      a.x = Math.max(-ARENA, Math.min(ARENA, a.x)); b.x = Math.max(-ARENA, Math.min(ARENA, b.x));
    }
    resolveHits(a, b); resolveHits(b, a);
    if (room.tick % TICK === 0) room.timer--;
    if (a.hp <= 0 || b.hp <= 0 || room.timer <= 0) {
      let w = -1;
      if (a.hp <= 0 && b.hp <= 0) w = -1;
      else if (a.hp <= 0) w = 1; else if (b.hp <= 0) w = 0;
      else if (a.hp !== b.hp) w = a.hp > b.hp ? 0 : 1;
      endRound(room, w);
    }
  } else if (room.phase === 'roundover') {
    // KOモーション中も物理は進める
    [a, b].forEach((p) => { if (p.y > 0 || p.vy > 0) { p.vy -= GRAVITY * DT; p.y = Math.max(0, p.y + p.vy * DT); } });
    room.phaseT--;
    if (room.phaseT <= 0) { room.round++; resetRound(room); }
  }

  const snap = {
    t: 's', ph: room.phase, pt: Math.ceil(room.phaseT / TICK), tm: room.timer, rd: room.round, msg: room.msg,
    p: room.players.map((p) => ({
      x: +p.x.toFixed(3), y: +p.y.toFixed(3), hp: Math.round(p.hp), f: p.face, s: p.state, m: p.move, st: p.stateT,
      w: p.wins, h: p.lastHit || null,
    })),
  };
  room.players.forEach((p) => { p.lastHit = null; });
  broadcast(room, snap);
}

setInterval(() => { for (const r of rooms.values()) if (r.phase !== 'waiting') tickRoom(r); }, 1000 / TICK);

// ---------- 接続管理 ----------
function code4() { return Math.random().toString(36).slice(2, 6).toUpperCase(); }

function onMessage(ws, msg) {
  if (msg.t === 'ping') return send(ws, { t: 'pong' });
  if (msg.t === 'join' && !ws.player) {
    const p = newPlayer(ws, msg.name, msg.char);
    ws.player = p;
    let room;
    if (msg.room) {
      const c = String(msg.room).toUpperCase().slice(0, 6);
      room = rooms.get(c);
      if (!room) { room = makeRoom(c); room.priv = true; rooms.set(c, room); }
      if (room.players.length >= 2) { send(ws, { t: 'err', m: 'そのルームは満員です' }); ws.player = null; return; }
    } else if (waiting && waiting.players.length === 1) {
      room = waiting; waiting = null;
    } else {
      room = makeRoom(code4()); rooms.set(room.code, room); waiting = room;
    }
    room.players.push(p); p.room = room;
    send(ws, { t: 'joined', room: room.code, you: room.players.length - 1 });
    if (room.players.length === 2) startMatch(room);
    else send(ws, { t: 'wait', room: room.code });
  } else if (msg.t === 'in' && ws.player) {
    const i = msg.i | 0;
    ws.player.input = { l: i & 1, r: i & 2, j: i & 4, a: i & 8, h: i & 16, b: i & 32 };
  } else if (msg.t === 'rematch' && ws.player && ws.player.room) {
    const room = ws.player.room;
    if (room.phase !== 'matchover') return;
    ws.player.rematch = true;
    if (room.players.length === 2 && room.players.every((p) => p.rematch)) startMatch(room);
  }
}

function onClose(ws) {
  const p = ws.player; if (!p || !p.room) return;
  const room = p.room;
  room.players = room.players.filter((q) => q !== p);
  if (waiting === room) waiting = null;
  if (room.players.length === 0) { rooms.delete(room.code); return; }
  // 相手が抜けた → 待機に戻す
  room.phase = 'waiting'; room.players[0].wins = 0; room.players[0].rematch = false;
  send(room.players[0].ws, { t: 'left', room: room.code });
  if (!room.priv && !waiting) waiting = room;   // クイックマッチなら再び待ち受けに戻す
}

// ---------- WebSocket (RFC6455 最小実装) ----------
function acceptUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) return socket.destroy();
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  let buf = Buffer.alloc(0);
  socket.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const op = buf[0] & 0x0f, masked = buf[1] & 0x80;
      let len = buf[1] & 0x7f, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > 65536) return socket.destroy();
      if (buf.length < off + (masked ? 4 : 0) + len) return;
      let payload;
      if (masked) {
        const mask = buf.slice(off, off + 4); payload = Buffer.from(buf.slice(off + 4, off + 4 + len));
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
        off += 4;
      } else payload = buf.slice(off, off + len);
      buf = buf.slice(off + len);
      if (op === 0x8) { socket.end(); return; }
      if (op === 0x9) { socket.write(Buffer.concat([Buffer.from([0x8a, payload.length]), payload])); continue; }
      if (op === 0x1) { try { onMessage(socket, JSON.parse(payload.toString('utf8'))); } catch (e) { /* 不正な入力は無視 */ } }
    }
  });
  const close = () => { if (!socket._closed) { socket._closed = true; onClose(socket); } };
  socket.on('close', close); socket.on('error', close);
}

// ---------- HTTP ----------
const server = http.createServer((req, res) => {
  let url = decodeURIComponent(req.url.split('?')[0]);
  if (url === '/healthz') { res.writeHead(200); return res.end('ok'); }
  if (url === '/') url = '/index.html';
  const file = path.normalize(path.join(PUBLIC, url));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('not found'); }
    const ext = path.extname(file);
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size };
    headers['Cache-Control'] = ext === '.glb' ? 'public, max-age=604800' : 'no-cache';
    res.writeHead(200, headers);
    fs.createReadStream(file).pipe(res);
  });
});
server.on('upgrade', (req, socket) => (req.url.startsWith('/ws') ? acceptUpgrade(req, socket) : socket.destroy()));
server.listen(PORT, () => console.log('fight server on :' + PORT));
